review15 replays - import in the UI: Settings -> Practice & Positions -> Import (opens in hotseat, both hands shown).

game4-turn8-your-missed-kill.json      game 4 at the start of your turn 8 (step 80). You had a forced kill (12 damage:
                                       Test Subject 2/1 face, Tetra & Ladica, super-evolve it, face, Alchemic Flare on
                                       Noel - its Skybound Art does the last 2). Your actual turn is on Redo.
game4-turn9-bot-turn-start.json        game 4 at the start of the bot's turn 9 (step 86). The bot played Yidmetra
                                       (on Redo). An earlier version of this file said Mars + Steelclad Knight + trades
                                       would have left you no kill. That was wrong: see the next file.
game4-turn9-after-Mars-clear-your-kill.json
                                       game 4 after that Mars clear (step 94): both boards empty, the bot at 9, you to
                                       move with 9 PP. You still kill: Tetra & Ladica, super-evolve it (8/8 Storm),
                                       hit face for 8, then fuse a card onto Sephie in your hand: for 2 PP she summons
                                       an Obsessed Test Subject, your Sephie crest gives it Storm, and it hits for 5.
                                       That line is on Redo (13 damage into 9).
game3-turn11-bot-Mars-clear-missed.json game 3 at the start of the bot's turn 11 (step 129). Same idea with Mars; the
                                       bot's actual turn (Cesar...) is on Redo.
games/gameNN-W.json / -L.json          all 4 games from the start (step 0); Redo steps forward. W/L = your result.

Games 1-4 in play order: your Rune Test Subject against the bot's Sword Rally (2026-10-09).
Built from the 4 serve.py captures (review15/games on the results branch). Every log replays legally to the recorded
winner on the capture's engine (ed574a4).
